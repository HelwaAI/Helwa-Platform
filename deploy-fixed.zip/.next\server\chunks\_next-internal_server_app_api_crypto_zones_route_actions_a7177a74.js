module.exports=[56997,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_crypto_zones_route_actions_a7177a74.js.map