module.exports=[66969,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stocks_zones_route_actions_b83ee49f.js.map