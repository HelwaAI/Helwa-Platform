module.exports=[71041,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_crypto_searchzoneid_route_actions_10fe44d9.js.map