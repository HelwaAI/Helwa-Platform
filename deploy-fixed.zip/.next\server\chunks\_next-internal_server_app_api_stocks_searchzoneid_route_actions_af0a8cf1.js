module.exports=[70535,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stocks_searchzoneid_route_actions_af0a8cf1.js.map