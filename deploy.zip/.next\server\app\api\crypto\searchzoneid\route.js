var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/crypto/searchzoneid/route.js")
R.c("server/chunks/[root-of-the-server]__1b9c6b19._.js")
R.c("server/chunks/[root-of-the-server]__58e47018._.js")
R.c("server/chunks/_next-internal_server_app_api_crypto_searchzoneid_route_actions_10fe44d9.js")
R.m(33678)
module.exports=R.m(33678).exports
