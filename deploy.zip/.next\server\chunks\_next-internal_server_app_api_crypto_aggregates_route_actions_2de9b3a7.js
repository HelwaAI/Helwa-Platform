module.exports=[10915,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_crypto_aggregates_route_actions_2de9b3a7.js.map