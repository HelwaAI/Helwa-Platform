var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/crypto/zones/route.js")
R.c("server/chunks/[root-of-the-server]__1edd3e26._.js")
R.c("server/chunks/[root-of-the-server]__58e47018._.js")
R.c("server/chunks/_next-internal_server_app_api_crypto_zones_route_actions_a7177a74.js")
R.m(55995)
module.exports=R.m(55995).exports
