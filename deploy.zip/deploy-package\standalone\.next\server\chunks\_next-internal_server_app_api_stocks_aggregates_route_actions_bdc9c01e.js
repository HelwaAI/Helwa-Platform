module.exports=[27717,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stocks_aggregates_route_actions_bdc9c01e.js.map