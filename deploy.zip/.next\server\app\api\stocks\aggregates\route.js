var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/stocks/aggregates/route.js")
R.c("server/chunks/[root-of-the-server]__906bd285._.js")
R.c("server/chunks/[root-of-the-server]__58e47018._.js")
R.c("server/chunks/_next-internal_server_app_api_stocks_aggregates_route_actions_bdc9c01e.js")
R.m(22501)
module.exports=R.m(22501).exports
