var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/crypto/aggregates/route.js")
R.c("server/chunks/[root-of-the-server]__2be32414._.js")
R.c("server/chunks/[root-of-the-server]__58e47018._.js")
R.c("server/chunks/_next-internal_server_app_api_crypto_aggregates_route_actions_2de9b3a7.js")
R.m(19928)
module.exports=R.m(19928).exports
