var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/stocks/zones/route.js")
R.c("server/chunks/[root-of-the-server]__b298b271._.js")
R.c("server/chunks/[root-of-the-server]__58e47018._.js")
R.c("server/chunks/_next-internal_server_app_api_stocks_zones_route_actions_b83ee49f.js")
R.m(1902)
module.exports=R.m(1902).exports
