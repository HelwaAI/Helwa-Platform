module.exports=[34816,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_cryptoDashboard_page_actions_6e746703.js.map