module.exports=[58283,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stocks_entrytargetstoploss_route_actions_e6400877.js.map